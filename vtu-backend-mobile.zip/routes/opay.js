const express = require("express");
const router = express.Router();
const axios = require("axios");

router.post("/fund-wallet", async (req, res) => {
  const { amount, reference } = req.body;
  try {
    const response = await axios.post("https://api.opaycheckout.com/api/v1/initiate", {
      amount,
      reference
    }, {
      headers: { Authorization: `Bearer ${process.env.OPAY_SECRET_KEY}` }
    });

    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
