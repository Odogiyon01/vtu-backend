const express = require("express");
const router = express.Router();
const axios = require("axios");

router.post("/buy-data", async (req, res) => {
  const { network, plan, phone } = req.body;
  try {
    const response = await axios.post("https://smeplug.ng/api/v1/data", {
      network,
      plan,
      phone
    }, {
      headers: { Authorization: `Bearer ${process.env.SMEPLUG_SECRET_KEY}` }
    });

    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
