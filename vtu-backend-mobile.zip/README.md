# VTU Backend (SMEPlug + Opay)

## Setup
1. Upload this project to GitHub.
2. Connect repository to Render.com.
3. Add Environment Variables in Render:
   - SMEPLUG_SECRET_KEY=your_smeplug_api_key
   - OPAY_SECRET_KEY=your_opay_api_key
4. Deploy as Node.js web service.

## API Endpoints
### Buy Data
POST /smeplug/buy-data
```json
{
  "network": "mtn",
  "plan": "1GB",
  "phone": "08012345678"
}
```

### Fund Wallet
POST /opay/fund-wallet
```json
{
  "amount": 1000,
  "reference": "TXN12345"
}
```
