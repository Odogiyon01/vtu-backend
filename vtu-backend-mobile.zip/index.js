const express = require("express");
const bodyParser = require("body-parser");
require("dotenv").config();

const smeplugRoutes = require("./routes/smeplug");
const opayRoutes = require("./routes/opay");

const app = express();
app.use(bodyParser.json());

// Routes
app.use("/smeplug", smeplugRoutes);
app.use("/opay", opayRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
